
DATAPACKAGE: NATIONAL GENERATION CAPACITY
===========================================================================

https://doi.org/10.25832/national_generation_capacity/2019-12-02

by Open Power System Data: http://www.open-power-system-data.org/

Package Version: 2019-12-02

Aggregated generation capacity by technology and country

This data package comprises technology-specific aggregated generation
capacities for European countries. The generation capacities are
consistently categorized based on fuel and technology. For each European
country, various references are used ranging from international (e.g.
ENTSOE or EUROSTAT) to national sources from e.g. regulatory authorities.
The input data is processed in the script linked below.

The data package covers the geographical region of Austria, Belgium, Bulgaria, Switzerland, Czech Republic, Germany, Denmark, Estonia, Spain, Finland, France, Greece, Hungary, Irland, Italy, Lithuania, Luxemburg, Latvia, the Netherlands, Norway, Poland, Portugal, Romania, Sweden, Slovenia, Slovakia, United Kingdom.

We follow the Data Package standard by the Frictionless Data project, a
part of the Open Knowledge Foundation: http://frictionlessdata.io/


Documentation and script
===========================================================================

This README only contains the most basic information about the data package.
For the full documentation, please see the notebook script that was used to
generate the data package. You can find it at:

https://nbviewer.jupyter.org/github/Open-Power-System-Data/national_generation_capacity/blob/2019-12-02/main.ipynb

Or on GitHub at:

https://github.com/Open-Power-System-Data/national_generation_capacity/blob/2019-12-02/main.ipynb

License and attribution
===========================================================================

Attribution:
    Attribution should be given as follows: Open Power System Data. 2019.
    Data Package National generation capacity. Version 2019-12-02.
    https://doi.org/10.25832/national_generation_capacity/2019-12-02.
    (Primary data from various sources, for a complete list see URL).


Version history
===========================================================================

* 2019-12-02 Updated data for 2019, bugfixes, inclusion of ENTSOE Power Statistics and Transparency Platform
* 2019-02-22 Updated data for 2018, bugfixes
* 2017-07-07 Revised technology classification, restructured input file format, adjusted input data to final version
* 2016-10-27 Revised technology classification, restructured input file format, adjusted input data to final version


Resources
===========================================================================

* [Package description page](http://data.open-power-system-data.org/national_generation_capacity/2019-12-02/)
* [Script and documentation](https://github.com/Open-Power-System-Data/national_generation_capacity/blob/2019-12-02/main.ipynb)
* [Original input data](http://data.open-power-system-data.org/national_generation_capacity/2019-12-02/original_data/)


Sources
===========================================================================

* [EUROSTAT](http://ec.europa.eu/eurostat/product?code=nrg_113a&mode=view)
* [UN Statistical Office](http://data.un.org/Data.aspx?d=EDATA&f=cmID%3AEC)
* [ENTSOE Statistics](https://www.entsoe.eu/db-query/miscellaneous/net-generating-capacity)
* [ENTSOE Power Statistics](https://www.entsoe.eu/data/power-stats/net-gen-capacity/)
* [ENTSOE SO&AF](https://www.entsoe.eu/outlooks/maf/Pages/default.aspx)
* [ENTSOE Transparency Platform](https://transparency.entsoe.eu/generation/r2/installedGenerationCapacityAggregation/show)
* [e-control](http://www.e-control.at/statistik/strom/bestandsstatistik)
* [ELIA](http://www.elia.be/en/grid-data/power-generation/generating-facilities)
* [TSO Bulgaria](http://www.eso.bg/?did=79#Reports)
* [BFE](https://www.bfe.admin.ch/bfe/de/home/versorgung/statistik-und-geodaten/energiestatistiken/elektrizitaetsstatistik.html)
* [ERU](https://www.eru.cz/en/zpravy-o-provozu-elektrizacni-soustavy)
* [BMWi](https://www.bmwi.de/Redaktion/DE/Artikel/Energie/energiedaten-gesamtausgabe.html)
* [DEA](https://ens.dk/en/our-services/statistics-data-key-figures-and-energy-maps/annual-and-monthly-statistics)
* [Statistics Estonia](http://pub.stat.ee/px-web.2001/Dialog/varval.asp?ma=FE032&ti=CAPACITY+AND+PRODUCTION+OF+POWER+PLANTS&path=../I_Databas/Economy/07Energy/02Energy_consumption_and_production/01Annual_statistics/&lang=1)
* [REE](http://www.ree.es/en/statistical-data-of-spanish-electrical-system/national-indicators/national-indicators)
* [RTE](https://www.services-rte.com/en/view-data-published-by-rte/production-installed-capacity.html)
* [Statistics Finland](http://pxnet2.stat.fi/PXWeb/pxweb/en/StatFin_Passiivi/StatFin_Passiivi__ene__ehk/statfinpas_ehk_pxt_904_201500_en.px/)
* [Department of Energy & Climate Change UK](https://www.gov.uk/government/statistics/electricity-chapter-5-digest-of-united-kingdom-energy-statistics-dukes)
* [REA](http://www.rae.gr/site/en_US/categories_new/about_rae/actions/reports_national.csp)
* [HOPS](https://www.hops.hr/en/basic-data)
* [Mavir](https://www.mavir.hu/hu/web/mavir-en/installed-generation-capacity)
* [Eirgrid](http://www.eirgridgroup.com/library/)
* [Terna](https://www.terna.it/en/electric-system/transparency-report/installed-capacity)
* [Litgrid](https://www.litgrid.eu/index.php/power-system/power-system-information/generation-capacity/546)
* [Central Statistical Bureau of Latvia](http://data1.csb.gov.lv/pxweb/en/vide/vide__energetika__ikgad/?tablelist=true)
* [Tennet](https://www.tennet.org/english/operational_management/export_data.aspx)
* [Statistics Norway](https://www.ssb.no/en/energi-og-industri/statistikker/elektrisitet/aar)
* [CIRE](http://www.rynek-energii-elektrycznej.cire.pl/st,33,207,tr,75,0,0,0,0,0,podstawowe-dane.html)
* [REN](http://www.ren.pt/en-GB/media/publications/)
* [ANRE](https://www.anre.ro/en/about-anre/annual-reports-archive)
* [Swedish Energy Agency](https://www.energimyndigheten.se/en/facts-and-figures/publications/)
* [Agencija za energijo](https://www.agen-rs.si/web/en/publications/-/asset_publisher/TCdo6cWN9Shk/content/te-1?_101_INSTANCE_TCdo6cWN9Shk_redirect=%2Fweb%2Fen%2Fpublications)
* [Statistical Office of Slovakia](https://slovak.statistics.sk/wps/portal/ext/themes/multi/energy/publications)


Field documentation
===========================================================================


national_generation_capacity_stacked.csv
---------------------------------------------------------------------------

* id
    - Type: integer
    - Description: ID for data entries
* technology
    - Type: string
    - Description: Generation technology defined by fuel and conversion technology
* source
    - Type: string
    - Description: Source of data entry
* source_type
    - Type: string
    - Description: Type of data source
* year
    - Type: integer
    - Format: YYYY
    - Description: Year of data entry
* type
    - Type: string
    - Description: Type of capacity (e.g. installed capacity)
* country
    - Type: string
    - Description: Country ISO code
* capacity_definition
    - Type: string
    - Description: Capacity definition used in the relevant source (net, gross, or unknown)
* comment
    - Type: string
    - Description: Comments on data entry
* capacity
    - Type: float
    - Description: Installed capacity in MW
* energy_source_level_0
    - Type: boolean
    - Description: Energy source level 0 (total aggregated capacity)
* energy_source_level_1
    - Type: boolean
    - Description: Energy source level 1 (aggregation or classification by type of fuel)
* energy_source_level_2
    - Type: boolean
    - Description: Energy source level 2 (aggregation or classification by fuel)
* energy_source_level_3
    - Type: boolean
    - Description: Energy source level 3 (aggregation or classification by fuel refined for bioenergy)
* technology_level
    - Type: boolean
    - Description: Technology (aggregation or classification by fuel and technology)


Feedback
===========================================================================

Thank you for using data provided by Open Power System Data. If you have
any question or feedback, please do not hesitate to contact us.

For this data package, contact:
Mario Kendziorski <mak@wip.tu-berlin.de>

Elmar Zozmann <ez@wip.tu-berlin.de>

Friedrich Kunz
For general issues, find our team contact details on our website:
http://www.open-power-system-data.org














